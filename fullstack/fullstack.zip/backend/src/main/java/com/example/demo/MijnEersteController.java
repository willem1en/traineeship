package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(maxAge = 3600)
@RestController
public class MijnEersteController {
	
	@Autowired
	private IPersonRepository personRepository;
	
	@Autowired
	private IAddressRepository addressRepository;
	
	// Endpoint
	
	@RequestMapping("demo")
	public String demo() {
		return "Willemien";
	}

	@RequestMapping("personen")
	public List<Person> vindAllePersonen(@RequestParam String n) {
		return personRepository.findByNameStartsWith(n);
	}
	
	@RequestMapping("adressen")
	public List<Address> vindAlleAdressen(@RequestParam(required = false, defaultValue = "") String a) {
		return addressRepository.findByStreetName(a);
	}
	
	@RequestMapping("zoeken")
	public List<Address> vindEenAdres(@RequestParam(required = false, defaultValue = "") String n) {
		return addressRepository.findByStreetNameContaining(n);
	}
}
