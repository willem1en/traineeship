function createAddress() {
    // Formulier uitlezen
    let nieuweNaamInvoer = document.getElementById('newAddress').value;

    let newAddress = {
        name: nieuweNaamInvoer
    }

    fetch("http://localhost:8080/api/adressen", {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(newAddress)
    })
        .then(response => {
            alert('Is goedgegaan');
        })
        .catch(error => {
            alert('Er is iets fouts gegaan');
        });
}

function show(data) {
    let addressTableHtml =
        `<tr>
                <th>ID</th>
                <th>Streetname</th>
                <th>Housenumber</th>
                <th>Postcode</th>
                <th>Plaatsnam</th>
             </tr>`;

    // Loop to access all rows 
    for (let r of data) {
        addressTableHtml += `<tr> 
                <td>${r.id} </td>
                <td>${r.streetName}</td>
                <td>${r.houseNumber}</td>
                <td>${r.postCode}</td>
                <td>${r.city}</td>
            </tr>`;
    }

    // Setting innerHTML as tab variable
    document.getElementById("addresses").innerHTML = addressTableHtml;
}

function getapi() {
    fetch("http://localhost:8080/adressen?a=Pleiadenlaan")
        .then(response => response.json())
        .then(addressList => {
            console.log('response', addressList);
            show(addressList);
        })
        .catch(error => {
            console.log('error', error);
            // handle the error
        });
}

function searchAdres() {
    var value = document.getElementById('searchValue').value;
    var searchString = "http://localhost:8080/adressen?a=" + value;
    fetch (searchString)
        .then(response => response.json())
        .then(addressList => {
            console.log('response', addressList);
            show(addressList);
        })
        .catch(error => {
            console.log('error', error);
            // handle the error
        });
}

function adresContains() {
    var value = document.getElementById('searchValue').value;
    var searchString = "http://localhost:8080/zoeken?n=" + value;
    fetch (searchString)
        .then(response => response.json())
        .then(addressList => {
            console.log('response', addressList);
            show(addressList);
        })
        .catch(error => {
            console.log('error', error);
            // handle the error
        });
}

getapi();
